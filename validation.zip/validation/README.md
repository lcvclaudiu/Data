# L=3 exhaustive validation

The original L=3 end-to-end check was run interactively and its terminal output was retained with the manuscript work. `validate_L3_end_to_end.py` collects the same deterministic checks into a reproducible program.

For L=3 there are nine binary cell variables, so the program enumerates all 512 configurations and all 4608 directed single-cell flips. It verifies the boundary-chain condition and the Betti-number mapping, evaluates the finite Matsubara update against direct diagonalization, and compares the stationary distributions of the biased finite-cutoff Markov kernels with their exact targets.

The rank check is performed directly on `B2`. This is deliberate: square-rooting roundoff-scale eigenvalues of `B2.T @ B2` can make exact null modes appear nonzero.

The production cutoff can be checked at all four temperatures with

```bash
python validate_L3_end_to_end.py \
  --temps 0.0038 0.005 0.006 0.010 \
  --nfreqs 128 \
  --outdir validation/L3_check
```

To inspect cutoff convergence as well, use

```bash
python validate_L3_end_to_end.py \
  --temps 0.0038 \
  --nfreqs 32 64 128 256 \
  --outdir validation/L3_cutoff
```

The optional MBAR stage generates the standard ten L=3 umbrella centers with two replicas per center and runs the same `analyze_mbar.py` used for the production analysis:

```bash
python validate_L3_end_to_end.py \
  --temps 0.0038 \
  --nfreqs 128 \
  --production-nfreq 128 \
  --run-mbar \
  --outdir validation/L3_T0038
```

The umbrella files are generated only when `--run-mbar` is requested. They are not part of the repository archive.
