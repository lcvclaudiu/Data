#!/usr/bin/env bash
set -euo pipefail

echo "============================================================"
echo "STITCH REMAINING STATISTICAL VALIDATION"
echo "Started: $(date)"
echo "============================================================"

# T/J = 0.0038
bash run_one_stats.sh 6  0.0038 runs/T0038/L6  T0038_L6  20
bash run_one_stats.sh 8  0.0038 runs/T0038/L8  T0038_L8  24
bash run_one_stats.sh 10 0.0038 runs/T0038/L10 T0038_L10 33
bash run_one_stats.sh 12 0.0038 runs/T0038/L12 T0038_L12 39

# T/J = 0.005
# L8 CLOSED
# L10 CLOSED
# L12 pending

# T/J = 0.006
# L8 CLOSED
# L10 CLOSED
# L12 pending

# T/J = 0.010
bash run_one_stats.sh 6  0.0100 runs/T001/L6  T001_L6  20
bash run_one_stats.sh 8  0.0100 runs/T001/L8  T001_L8  24
bash run_one_stats.sh 10 0.0100 runs/T001/L10 T001_L10 33

echo
echo "============================================================"
echo "ALL CURRENTLY FINISHED DATASETS COMPLETE"
echo "Finished: $(date)"
echo "============================================================"
